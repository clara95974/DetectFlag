#ifndef GRP2_Lib_IA_LIBRARY_H
#define GRP2_Lib_IA_LIBRARY_H

#include <cstdint>

void delete_int_array(int* arr, int arr_len);


/*
   ==================================================================================================================

                                                               ML


   ==================================================================================================================
*/

struct MyLinearModel;
MyLinearModel* create_linear_model(int32_t input_size, int32_t output_size, bool isClassification);

void train_linear_model(MyLinearModel* model, float* dataset_inputs, int32_t lines, int32_t columns,
                        float* dataset_outputs, int32_t output_columns, float alpha, int32_t nb_iter);

void predict_linear_model(MyLinearModel* ml, float* sample_inputs, int32_t columns, float* prediction);

void save_linear_model(MyLinearModel* ml, const char* filename);

MyLinearModel* load_linear_model(const char* filename);

void get_weights_linear_model(MyLinearModel* ml, float** weights);

void get_bias_linear_model(MyLinearModel* ml, float* bias);

void delete_linear_model(MyLinearModel* ml);



/*
   ==================================================================================================================

                                                               MLP


   ==================================================================================================================
*/


struct MyMLP;
MyMLP* create_mlp_model(int* arr, int arr_len, bool isClassification);

void train_mlp_model(MyMLP* model, float* dataset_inputs, int lines, int columns,float* dataset_outputs, int output_columns, float alpha, int nb_iter);

float* predict_mlp_model(MyMLP* model, float* sample_inputs, int columns);

void save_mlp_model(MyMLP* model, const char* filename);

MyMLP* load_mlp_model(const char* filename);

void get_weights_mlp_model(MyMLP* model, float**** weights);

void get_bias_mlp_model(MyMLP* model, float** bias);

void delete_mlp_model(MyMLP* model);

void delete_float_array(float* arr);

/*
   ==================================================================================================================

                                                               RBF


   ==================================================================================================================
*/

struct MyRBFModel;

DLLEXPORT MyRBFModel* create_rbf_model(int32_t num_classes, int32_t num_centers, float gamma);

DLLEXPORT void train_rbf_model(MyRBFModel* model, float* dataset_inputs, int32_t lines, int32_t columns,
float* dataset_outputs, int32_t output_columns, int32_t epochs, float learning_rate);

DLLEXPORT float* predict_rbf_model(MyRBFModel* model, float* sample_inputs, int32_t columns);

DLLEXPORT void load_rbf_model(MyRBFModel* model, const char* filenameCenters, const char* filenameWeights);

DLLEXPORT void delete_rbf_model(MyRBFModel* model);

DLLEXPORT void delete_float_array(float* arr);

#endif
