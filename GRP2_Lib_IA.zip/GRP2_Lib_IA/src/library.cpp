

#include <cstdint>
#include <cstdlib>
#include <ctime>
#include <iostream>
#include <fstream>

#ifdef WIN32
#define DLLEXPORT __declspec(dllexport)
#endif

extern "C" {

    DLLEXPORT void delete_int_array(int32_t* arr, int32_t arr_len) {
        delete[] arr;
    }

    /*
       ==================================================================================================================

                                                           ML

       ==================================================================================================================
    */

    struct MyLinearModel {
        int32_t input_size;
        int32_t output_size;
        float** weights;
        float* bias;
        bool isClassification;
    };

    DLLEXPORT MyLinearModel* create_linear_model(int32_t input_size, int32_t output_size, bool isClassification) {
        auto model = new MyLinearModel();

        model->input_size = input_size;
        model->output_size = output_size;
        model->isClassification = isClassification;

        model->weights = new float* [input_size];
        for (int32_t i = 0; i < input_size; ++i) {
            model->weights[i] = new float[output_size];
        }

        model->bias = new float[output_size];

        srand(static_cast<unsigned>(time(0)));
        for (int32_t i = 0; i < input_size; ++i) {
            for (int32_t j = 0; j < output_size; ++j) {
                model->weights[i][j] = (2.0 * rand() / RAND_MAX) - 1.0;
            }
        }

        for (int32_t j = 0; j < output_size; ++j) {
            model->bias[j] = (2.0 * rand() / RAND_MAX) - 1.0;
        }

        return model;
    }

    DLLEXPORT void train_linear_model(MyLinearModel* model, float* dataset_inputs, int32_t lines, int32_t columns,
    float* dataset_outputs, int32_t output_columns, float alpha, int32_t nb_iter) {
        for (int32_t iter = 0; iter < nb_iter; ++iter) {
            for (int32_t l = 0; l < lines; ++l) {
            auto prediction = new float[model->output_size];
            for (int32_t j = 0; j < model->output_size; ++j) {
                prediction[j] = model->bias[j];
                for (int32_t k = 0; k < model->input_size; ++k) {
                    prediction[j] += dataset_inputs[l * columns + k] * model->weights[k][j];
                }
            }

            if (model->isClassification) {
                for (int32_t j = 0; j < model->output_size; ++j) {
                    float y_hat = prediction[j];
                    float y_true = dataset_outputs[l * output_columns + j];
                    if ((y_true == 1 && y_hat <= 0) || (y_true == 0 && y_hat > 0)) {
                        for (int32_t k = 0; k < model->input_size; ++k) {
                            model->weights[k][j] += alpha * (y_true - y_hat) * dataset_inputs[l * columns + k];
                        }
                    model->bias[j] += alpha * (y_true - y_hat);
                    }
                }
            }
            else {
                for (int32_t j = 0; j < model->output_size; ++j) {
                    float y_hat = prediction[j];
                    float y_true = dataset_outputs[l * output_columns + j];
                    for (int32_t k = 0; k < model->input_size; ++k) {
                        model->weights[k][j] += alpha * (y_true - y_hat) * dataset_inputs[l * columns + k];
                    }
                    model->bias[j] += alpha * (y_true - y_hat);
                }
            }
            delete[] prediction;
        }
        }
    }

    DLLEXPORT void predict_linear_model(MyLinearModel* ml, float* sample_inputs, int32_t columns, float* prediction) {
        for (int32_t j = 0; j < ml->output_size; ++j) {
            ml->bias[j];
            for (int32_t k = 0; k < ml->input_size; ++k) {
                prediction[j] += sample_inputs[k] * ml->weights[k][j];
            }
        }
    }

    DLLEXPORT void save_linear_model(MyLinearModel* ml, const char* filename) {

        std::ofstream file(filename);

        if (file.is_open()) {
            file << "# Taille de l'entrée et de la sortie\n";
            file << ml->input_size << " " << ml->output_size << "\n";

            file << "# Poids\n";
            for (int32_t i = 0; i < ml->input_size; ++i) {
                for (int32_t j = 0; j < ml->output_size; ++j) {
                    file << "# Poids [" << i << "][" << j << "]\n";
                    file << ml->weights[i][j] << " ";
                }
                file << "\n";
            }

            // Enregistre les biais dans un fichier
            file << "# Biais\n";
            for (int32_t j = 0; j < ml->output_size; ++j) {
                file << "# Biais [" << j << "]\n";
                file << ml->bias[j] << " ";
            }

            file.close();
        }
        else {
            std::cerr << "Impossible d'ouvrir le fichier : " << filename << std::endl;
        }
    }


    DLLEXPORT MyLinearModel* load_linear_model(const char* filename) {
        std::ifstream file(filename);

        if (file.is_open()) {
            MyLinearModel* ml = new MyLinearModel();

            file >> ml->input_size >> ml->output_size;

            ml->weights = new float* [ml->input_size];
            for (int32_t i = 0; i < ml->input_size; ++i) {
                ml->weights[i] = new float[ml->output_size];
            }

            ml->bias = new float[ml->output_size];

            for (int32_t i = 0; i < ml->input_size; ++i) {
                for (int32_t j = 0; j < ml->output_size; ++j) {
                    file >> ml->weights[i][j];
                }
            }

            for (int32_t j = 0; j < ml->output_size; ++j) {
                file >> ml->bias[j];
            }

            file.close();
            return ml;
        }
        else {
            std::cerr << "Impossible d'ouvrir le fichier: " << filename << std::endl;
            return nullptr;
        }
    }

    DLLEXPORT void get_weights_linear_model(MyLinearModel* ml, float** weights) {
        for (int32_t i = 0; i < ml->input_size; ++i) {
            for (int32_t j = 0; j < ml->output_size; ++j) {
                weights[i][j] = ml->weights[i][j];
            }
        }
    }

    DLLEXPORT void get_bias_linear_model(MyLinearModel* ml, float* bias) {
        for (int32_t j = 0; j < ml->output_size; ++j) {
            bias[j] = ml->bias[j];
        }
    }

    DLLEXPORT void delete_linear_model(MyLinearModel* ml) {
        for (int32_t i = 0; i < ml->input_size; ++i) {
            delete[] ml->weights[i];
        }
        delete[] ml->weights;
        delete[] ml->bias;
        delete ml;
    }

    /*
       ==================================================================================================================

                                                           MLP

       ==================================================================================================================
    */

    struct MyMLP {
        int32_t nb_layer;
        int32_t* neurons_per_layer;
        float*** W;
        float** X;
        float** deltas;
        bool isClassification;
    };

    DLLEXPORT MyMLP* create_mlp_model(int32_t* arr, int32_t arr_len, bool isClassification) {
        auto model = new MyMLP();

        model->nb_layer = arr_len;
        model->neurons_per_layer = new int32_t[arr_len];
        model->W = new float** [arr_len - 1];
        model->X = new float* [arr_len];
        model->deltas = new float* [arr_len];
        model->isClassification = isClassification;

        for (int32_t i = 0; i < arr_len; ++i) {
            model->neurons_per_layer[i] = arr[i];
            model->X[i] = new float[arr[i]];
            model->deltas[i] = new float[arr[i]];

            if (i < arr_len - 1) {
                model->W[i] = new float* [arr[i]];
                for (int32_t j = 0; j < arr[i]; ++j) {
                    model->W[i][j] = new float[arr[i + 1]];
                }
            }
        }

        srand(static_cast<unsigned>(time(0)));
        for (int32_t i = 0; i < arr_len - 1; ++i) {
            for (int32_t j = 0; j < arr[i]; ++j) {
                for (int32_t k = 0; k < arr[i + 1]; ++k) {
                    model->W[i][j][k] = (2.0 * rand() / RAND_MAX) - 1.0;
                }
            }
        }

        return model;
    }

    DLLEXPORT void train_mlp_model(MyMLP* model, float* dataset_inputs, int32_t lines, int32_t columns,
    float* dataset_outputs, int32_t output_columns, float alpha, int32_t nb_iter) {
        for (int32_t iter = 0; iter < nb_iter; ++iter) {
            for (int32_t l = 0; l < lines; ++l) {
                for (int32_t i = 0; i < model->nb_layer; ++i) {
                    for (int32_t j = 0; j < model->neurons_per_layer[i]; ++j) {
                        if (i == 0) {
                            model->X[i][j] = dataset_inputs[l * columns + j];
                        }
                        else {
                            model->X[i][j] = 0.0;
                            for (int32_t k = 0; k < model->neurons_per_layer[i - 1]; ++k) {
                                model->X[i][j] += model->X[i - 1][k] * model->W[i - 1][k][j];
                            }
                        }
                    }
                }

                for (int32_t i = model->nb_layer - 1; i >= 0; --i) {
                    for (int32_t j = 0; j < model->neurons_per_layer[i]; ++j) {
                            if (i == model->nb_layer - 1) {
                                model->deltas[i][j] = model->X[i][j] - dataset_outputs[l * output_columns + j];
                            }
                        else {
                            model->deltas[i][j] = 0.0;
                            for (int32_t k = 0; k < model->neurons_per_layer[i + 1]; ++k) {
                                model->deltas[i][j] += model->deltas[i + 1][k] * model->W[i][j][k];
                            }
                            model->deltas[i][j] *= model->X[i][j] * (1.0 - model->X[i][j]);
                        }
                    }
                }

                for (int32_t i = 0; i < model->nb_layer - 1; ++i) {
                    for (int32_t j = 0; j < model->neurons_per_layer[i]; ++j) {
                        for (int32_t k = 0; k < model->neurons_per_layer[i + 1]; ++k) {
                            model->W[i][j][k] -= alpha * model->deltas[i + 1][k] * model->X[i][j];
                        }
                    }
                }
            }
        }
    }

    DLLEXPORT float* predict_mlp_model(MyMLP* model, float* sample_inputs, int32_t columns) {
        for (int32_t i = 0; i < model->nb_layer; ++i) {
            for (int32_t j = 0; j < model->neurons_per_layer[i]; ++j) {
                if (i == 0) {
                    model->X[i][j] = sample_inputs[j];
                }
                else {
                    model->X[i][j] = 0.0;
                    for (int32_t k = 0; k < model->neurons_per_layer[i - 1]; ++k) {
                        model->X[i][j] += model->X[i - 1][k] * model->W[i - 1][k][j];
                    }
                }
            }
        }

        auto prediction = new float[model->neurons_per_layer[model->nb_layer - 1]];
        for (int32_t i = 0; i < model->neurons_per_layer[model->nb_layer - 1]; ++i) {
            prediction[i] = model->X[model->nb_layer - 1][i];
        }

        return prediction;
    }

    DLLEXPORT void save_mlp_model(MyMLP* model, const char* filename) {

        std::ofstream file(filename);

        if (file.is_open()) {
            file << "# Nombre de couches et type (classification ou non)\n";
            file << model->nb_layer << " " << model->isClassification << "\n";

            file << "# Nombre de neurones par couche\n";
            for (int32_t i = 0; i < model->nb_layer; ++i) {
                file << "# Couche [" << i << "]\n";
                file << model->neurons_per_layer[i] << " ";
            }
            file << "\n";

            file << "# Poids\n";
            for (int32_t i = 0; i < model->nb_layer - 1; ++i) {
                for (int32_t j = 0; j < model->neurons_per_layer[i]; ++j) {
                    for (int32_t k = 0; k < model->neurons_per_layer[i + 1]; ++k) {
                        file << "# Poids [" << i << "][" << j << "][" << k << "]\n";
                        file << model->W[i][j][k] << " ";
                    }
                }
            }

            file.close();
        }
        else {
            std::cerr << "Impossible d'ouvrir le fichier : " << filename << std::endl;
        }
    }

    DLLEXPORT MyMLP* load_mlp_model(const char* filename) {
        std::ifstream file(filename);

        if (file.is_open()) {
            MyMLP* model = new MyMLP();

            file >> model->nb_layer >> model->isClassification;

            model->neurons_per_layer = new int32_t[model->nb_layer];
            model->W = new float** [model->nb_layer - 1];

            for (int32_t i = 0; i < model->nb_layer; ++i) {
                file >> model->neurons_per_layer[i];
            }

            model->X = new float* [model->nb_layer];
            model->deltas = new float* [model->nb_layer];

            for (int32_t i = 0; i < model->nb_layer; ++i) {
                model->X[i] = new float[model->neurons_per_layer[i]];
                model->deltas[i] = new float[model->neurons_per_layer[i]];

                if (i < model->nb_layer - 1) {
                    model->W[i] = new float* [model->neurons_per_layer[i]];
                    for (int32_t j = 0; j < model->neurons_per_layer[i]; ++j) {
                        model->W[i][j] = new float[model->neurons_per_layer[i + 1]];
                    }
                }
            }

            for (int32_t i = 0; i < model->nb_layer - 1; ++i) {
                for (int32_t j = 0; j < model->neurons_per_layer[i]; ++j) {
                    for (int32_t k = 0; k < model->neurons_per_layer[i + 1]; ++k) {
                        file >> model->W[i][j][k];
                    }
                }
            }

            file.close();
            return model;
        }
        else {
            std::cerr << "Impossible d'ouvrir le fichier " << filename << std::endl;
            return nullptr;
        }
    }

    DLLEXPORT void get_weights_mlp_model(MyMLP* model, float**** weights) {
        for (int32_t i = 0; i < model->nb_layer - 1; ++i) {
            for (int32_t j = 0; j < model->neurons_per_layer[i]; ++j) {
                for (int32_t k = 0; k < model->neurons_per_layer[i + 1]; ++k) {
                    weights[i][j][k] = &(model->W[i][j][k]);
                }
            }
        }
    }

    DLLEXPORT void get_bias_mlp_model(MyMLP* model, float*** bias) {
        for (int32_t i = 0; i < model->nb_layer - 1; ++i) {
            for (int32_t j = 0; j < model->neurons_per_layer[i + 1]; ++j) {
                bias[i][j] = &(model->X[i + 1][j]);
            }
        }
    }

    DLLEXPORT void delete_mlp_model(MyMLP* model) {
        for (int32_t i = 0; i < model->nb_layer; ++i) {
            delete[] model->X[i];
            delete[] model->deltas[i];

            if (i < model->nb_layer - 1) {
                for (int32_t j = 0; j < model->neurons_per_layer[i]; ++j) {
                    delete[] model->W[i][j];
                }
                delete[] model->W[i];
            }
        }

        delete[] model->neurons_per_layer;
        delete[] model->W;
        delete[] model->X;
        delete[] model->deltas;
        delete model;
    }

    DLLEXPORT void delete_float_array(float* arr) {
        delete[] arr;
    }

    /*
       ==================================================================================================================

                                                           RBF

       ==================================================================================================================
    */

    struct MyRBFModel {
        int32_t num_classes;
        int32_t num_centers;
        float gamma;
        float** centers;
        float** weights;
    };

    DLLEXPORT MyRBFModel* create_rbf_model(int32_t num_classes, int32_t num_centers, float gamma) {
        auto model = new MyRBFModel();
        model->num_classes = num_classes;
        model->num_centers = num_centers;
        model->gamma = gamma;

        model->centers = new float* [num_centers];
        for (int32_t i = 0; i < num_centers; ++i) {
            model->centers[i] = new float[num_classes];
        }

        model->weights = new float* [num_centers + 1];
        for (int32_t i = 0; i < num_centers + 1; ++i) {
            model->weights[i] = new float[num_classes];
        }

        srand(static_cast<unsigned>(time(0)));
        for (int32_t i = 0; i < num_centers; ++i) {
            for (int32_t j = 0; j < num_classes; ++j) {
                model->centers[i][j] = (2.0 * rand() / RAND_MAX) - 1.0;
            }
        }

        for (int32_t i = 0; i < num_centers + 1; ++i) {
            for (int32_t j = 0; j < num_classes; ++j) {
                model->weights[i][j] = (2.0 * rand() / RAND_MAX) - 1.0;
            }
        }

        return model;
    }

    DLLEXPORT void train_rbf_model(MyRBFModel* model, float* dataset_inputs, int32_t lines, int32_t columns,
    float* dataset_outputs, int32_t output_columns, int32_t epochs, float learning_rate) {
        for (int32_t epoch = 0; epoch < epochs; ++epoch) {
            float* activations = new float[lines * model->num_centers];
            for (int32_t i = 0; i < lines; ++i) {
                for (int32_t j = 0; j < model->num_centers; ++j) {
                    float diff = 0.0;
                    for (int32_t k = 0; k < columns; ++k) {
                        diff += std::pow(dataset_inputs[i * columns + k] - model->centers[j][k], 2);
                    }
                        activations[i * model->num_centers + j] = std::exp(-model->gamma * diff);
                    }
                }

                float* activations_bias = new float[lines * (model->num_centers + 1)];
                for (int32_t i = 0; i < lines; ++i) {
                    activations_bias[i * (model->num_centers + 1)] = 1.0;
                    for (int32_t j = 0; j < model->num_centers; ++j) {
                        activations_bias[i * (model->num_centers + 1) + j + 1] = activations[i * model->num_centers + j];
                    }
                }

                for (int32_t i = 0; i < model->num_centers + 1; ++i) {
                    for (int32_t j = 0; j < model->num_classes; ++j) {
                        float gradient = 0.0;
                        for (int32_t k = 0; k < lines; ++k) {
                        gradient += activations_bias[k * (model->num_centers + 1) + i] *
                        (model->weights[i][j] - dataset_outputs[k * output_columns + j]);
                        }
                        model->weights[i][j] -= learning_rate * gradient;
                    }
                }

                delete[] activations;
                delete[] activations_bias;
            }
    }

    DLLEXPORT float* predict_rbf_model(MyRBFModel* model, float* sample_inputs, int32_t columns) {

        float* activations = new float[model->num_centers];
        for (int32_t i = 0; i < model->num_centers; ++i) {
            float diff = 0.0;
            for (int32_t j = 0; j < columns; ++j) {
                diff += std::pow(sample_inputs[j] - model->centers[i][j], 2);
            }
            activations[i] = std::exp(-model->gamma * diff);
        }

        float* activations_bias = new float[model->num_centers + 1];
        activations_bias[0] = 1.0;
        for (int32_t i = 0; i < model->num_centers; ++i) {
            activations_bias[i + 1] = activations[i];
        }

        float* predictions = new float[model->num_classes];
        for (int32_t i = 0; i < model->num_classes; ++i) {
            predictions[i] = 0.0;
            for (int32_t j = 0; j < model->num_centers + 1; ++j) {
                predictions[i] += activations_bias[j] * model->weights[j][i];
            }
        }

        delete[] activations;
        delete[] activations_bias;

        return predictions;
    }

    DLLEXPORT void load_rbf_model(MyRBFModel* model, const char* filenameCenters, const char* filenameWeights) {
        std::ifstream centersFile(filenameCenters);
        if (centersFile.is_open()) {
            for (int32_t i = 0; i < model->num_centers; ++i) {
                for (int32_t j = 0; j < model->num_classes; ++j) {
                    centersFile >> model->centers[i][j];
                }
            }
            centersFile.close();
        } else {
            std::cerr << "Impossible d'ouvrir le ficheir " << filenameCenters << std::endl;
            return;
        }


        std::ifstream weightsFile(filenameWeights);
        if (weightsFile.is_open()) {
            for (int32_t i = 0; i < model->num_centers + 1; ++i) {
                for (int32_t j = 0; j < model->num_classes; ++j) {
                    weightsFile >> model->weights[i][j];
                }
            }
            weightsFile.close();
        } else {
            std::cerr << "Impossible d'ouvrir le fichier " << filenameWeights << std::endl;
            return;
        }
    }

    DLLEXPORT void delete_rbf_model(MyRBFModel* model) {
        for (int32_t i = 0; i < model->num_centers; ++i) {
            delete[] model->centers[i];
        }
        delete[] model->centers;

        for (int32_t i = 0; i < model->num_centers + 1; ++i) {
            delete[] model->weights[i];
        }
        delete[] model->weights;

        delete model;
    }
}
